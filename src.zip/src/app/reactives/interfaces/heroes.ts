export interface RegistrosUsuarios {
     nombre: string;
     descripcion: string;
     precio: string;
}  
