import { Injectable } from '@angular/core';
import { Heroes } from '../reactives/interfaces/heroes';

@Injectable({
  providedIn: 'root'
})
export class HeroesService {
  private _personajes: Heroes[] = [
    
  ];
  public get personajes() : Heroes[]{
    return[...this._personajes];
  }
  
  agregarHeroe(personaje: Heroes){
  this._personajes.push(personaje);
  }
  
    constructor() { }
  }
