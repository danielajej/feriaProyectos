import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConexionService } from 'src/app/services/conexion.service';
import { HeroesService } from 'src/app/services/heroes.service';
import { Heroes } from '../interfaces/heroes';

@Component({
  selector: 'app-agregar',
  templateUrl: './agregar.component.html',
  styleUrls: ['./agregar.component.css']
})
export class AgregarComponent implements OnInit {

  Marca : string [] = ["TMNT","DC Comics","Marvel Comics"]

  Genero : string [] = ["Hombre","Mujer"]

  url : string [] = []

  nuevo: Heroes = {
    nombre: '',
    url: '',
    descripcion: '',
    marca: '',
    genero: ''
  };
  Formulario: FormGroup = this.fb.group({
    nombre: [, [Validators.required, Validators.minLength(3)]],
    url: [, [Validators.required, Validators.minLength(0)]],
    descripcion: [, [Validators.required, Validators.minLength(0)]],
    marca: [,[Validators.required, Validators.minLength(0)]],
    genero: [,[Validators.required, Validators.minLength(0)] ],
  });
 
  constructor(private fb: FormBuilder, private conexion: ConexionService, private ps:HeroesService) {
    this.conexion.Get("personajes","GetAll").subscribe(dato => {console.log(dato)
    })
  }

  ngOnInit(): void {
  }

  campoEsValido(campo: string) {
    return this.Formulario.controls[campo].errors && this.Formulario.controls[campo].touched;
  }

  getImage(marca:string){
    if(marca === "TMNT"){
      return "https://static.wikia.nocookie.net/logocomics/images/1/1c/Logo-small.png"
    }else if(marca === "DC Comics"){
     return "https://seeklogo.com/images/D/DC-logo-76F2B96066-seeklogo.com.png";
    }else {
      return "https://multimediaservergroup.com/disney/img/marvel-comic.png"
    }
  }

  guardar() {
    this.conexion.Post('personajes', 'Insert', this.Formulario.value).subscribe((dato: any) => {
      console.log(dato);
      if (dato['estatus']) {
        this.Formulario.reset();
        this.ObtenerRegistro(dato['id']);
      }
    });
  }

  ObtenerRegistro(id: number) {
    this.conexion.Post('personajes', 'GetId', { 'id': id }).subscribe((dato: any) => {
      console.log(dato);
    });
  }
  
  Agregar(){
    if(this.nuevo.nombre.trim().length === 0) {
      return;
    }
    this.ps.agregarHeroe(this.nuevo);
    this.nuevo = {
      nombre: '',
      url: '',
      descripcion: '',
      marca: '',
      genero: ''
    };
  }

  getColor(genero:string){
    if(genero === "Hombre"){
      return "black"
    }else{
     return "red";
  }
};
}
