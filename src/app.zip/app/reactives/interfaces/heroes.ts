export interface Heroes {
     nombre: string;
     url: string;
     descripcion: string;
     marca: string;
     genero: string;
}  
