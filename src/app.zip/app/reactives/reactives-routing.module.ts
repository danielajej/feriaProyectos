import { NgModule } from '@angular/core';
import { ListaComponent } from './lista/lista.component';
import { UpdateComponent } from './update/update.component';
import { RouterModule, Routes } from '@angular/router';
import { AgregarComponent } from './agregar/agregar.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'lista', component: ListaComponent },
      { path: 'agregar', component: AgregarComponent },
      { path: 'update/:id', component: UpdateComponent },
      { path: '**', redirectTo: 'lista' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReactivesRoutingModule { }
