import { Component, OnInit } from '@angular/core';
import { ConexionService } from 'src/app/services/conexion.service';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.css']
})
export class ListaComponent implements OnInit {

  Lista: any = [] ;
  constructor(private conexion: ConexionService) {
    this.ObtenerLista();
  }

  getImage(marca:string){
    if(marca === "TMNT"){
      return "https://static.wikia.nocookie.net/logocomics/images/1/1c/Logo-small.png"
    }else if(marca === "DC Comics"){
     return "https://seeklogo.com/images/D/DC-logo-76F2B96066-seeklogo.com.png";
    }else {
      return "https://multimediaservergroup.com/disney/img/marvel-comic.png"
    }
  }

  getColor(genero:string){
    if(genero === "Hombre"){
      return "black"
    }else{
     return "red";
  }
  }

  ObtenerLista() {
    this.conexion.Get('personajes', 'GetAll').subscribe((dato: any) => {
      console.log(dato);
      this.Lista = dato;
    });
  }

  ngOnInit(): void {
  }

}
