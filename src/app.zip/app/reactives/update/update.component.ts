import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ConexionService } from 'src/app/services/conexion.service';
import { Heroes } from '../interfaces/heroes';

// Importacion de Swal para las alertas
import Swal from 'sweetalert2';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  lista : string [] = ["Hombre","Mujer"]
  genero : string [] = ["Hombre","Mujer"]

  marca : string [] = ["TMNT","DC Comics","Marvel Comics"]

  nuevo: Heroes = {
    nombre: '',
    url: '',
    descripcion: '',
    marca: '',
    genero: ''
  };
  
  Formulario: FormGroup = this.fb.group({
    id: [],
    nombre: [, [Validators.required, Validators.minLength(3)]],
    url: [, [Validators.required, Validators.minLength(0)]],
    descripcion: [, [Validators.required, Validators.minLength(0)]],
    genero: [, [Validators.required]],
    marca: [, [Validators.required]],
  });
  constructor(
    private fb: FormBuilder,
    private conexion: ConexionService,
    private router: Router,
    private activedRouter: ActivatedRoute) {
    const id = this.activedRouter.snapshot.params['id'];
    this.ObtenerRegistro(id);
   
  };

  getImage(marca:string){
    if(marca === "TMNT"){
      return "https://static.wikia.nocookie.net/logocomics/images/1/1c/Logo-small.png"
    }else if(marca === "DC Comics"){
     return "https://seeklogo.com/images/D/DC-logo-76F2B96066-seeklogo.com.png";
    }else {
      return "https://multimediaservergroup.com/disney/img/marvel-comic.png"
    }
  }

  getColor(genero:string){
    if(genero === "Hombre"){
      return "black"
    }else{
     return "red";
  }
  }

  ObtenerRegistro(id: any) {
      this.conexion.Post('personajes', 'GetId', { 'id': id }).subscribe((dato: any) => {
        this.Formulario.patchValue({
          id: dato.id,
          nombre: dato.nombre,
          url: dato.url,
          descripcion: dato.descripcion,
          marca: dato.marca,
          genero: dato.genero,
        });
      });
    }
  ngOnInit(): void {
  }

  campoEsValido(campo: string) {
    return this.Formulario.controls[campo].errors && this.Formulario.controls[campo].touched;
  }

  guardar() {
    this.conexion.Post('personajes', 'Update', this.Formulario.value).subscribe((dato: any) => {
      console.log(dato);
      if (dato['estatus']) {
        this.router.navigate(['reactive/lista']);
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Se acualizo el personaje correctamente',
          showConfirmButton: false,
          timer: 1500
        })
      }
    });
  };

  eliminar(id:any) {  
    Swal.fire({
      title: '¿Quieres eliminar este personaje?',
      text: "Una vez eliminado no hay vuelta atras",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Eliminar'
    }).then((result) => {
      if (result.isConfirmed) {this.conexion.Post('personajes', 'Delete', { id: id }).subscribe((dato: any) => {
        console.log(dato);
        if (dato['estatus']) {
          this.router.navigate(['reactive/lista']);
        Swal.fire(
          '!Eliminado¡',
          'El personaje ha sido Eliminado',
          'success'
        )
        };
        });
      };
    });
  }
  
}
