import { Component, OnInit } from '@angular/core';
interface MenuItem {
  texto: string;
  ruta: string;
}
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  reactiveMenu: MenuItem[] = [
    { texto: 'Agregar', ruta: './reactive/agregar' },
    { texto: 'Lista', ruta: './reactive/lista' },
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
